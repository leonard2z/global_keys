# global_keys
Globalkeys全局热键快捷操作</br>
基于AutoHotKey
按下两次Ctrl后再按</br></br>
t:输入当前时间</br></br>
z:口吐莲花</br></br>
l:口吐情话</br></br>
p:放首音乐</br></br>
h:文字变花</br></br>
r:朗读选中文字</br></br>
s:选中文字朗读文件保存到本地</br></br>

