# global_keys
Globalkeys是一个基于AutoHotKey的全局热键操作小工具</br></br>

<b>主要功能和操作方法:</b></br>


按下两次Ctrl后再按</br></br>
t:输入当前时间</br></br>

z:口吐芬芳</br></br>
l:口吐情话</br></br>
p:放首音乐</br></br>
h:文字变花</br></br>
r:朗读选中文字</br></br>
s:将选中文字转化为语音文件后保存到本地</br></br>
c:将选中的文件按文件名添加到计划中</br></br>
k:关闭指定名称进程</br></br></br></br>
<b>配置文件config.ini:</b></br>
[exe_to_ext]</br>
自定义每种格式文件的启动程序</br>
[global]</br>
time_format:自定义输出时间格式如 yyyy:MM:dd H:m:s</br></br>

<b>下载和运行:</b></br>
在releases中下载最近release的压缩包,解压至本地即可运行并使用.</br></br></br></br>
代码编译:</br>
安装官方AutoHotKey,使用命令行编译globalkeys.ahk文件
<a href="http://music.163.com/song?id=26328713&userid=480586877">Circle Of Transmigration</a>
